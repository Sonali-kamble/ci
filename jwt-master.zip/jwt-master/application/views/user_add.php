<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Code</title> 
 
</head>
<body>

<div id="container">
<h2>User Add Page</h2>
</div>

</body>
</html>
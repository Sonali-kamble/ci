<?php  if(!defined("BASEPATH")) exit("No direct script access allowed");

$route["home"] = "home/index"; 

<?php

class login_model extends CI_Model {
	
 
	 
}